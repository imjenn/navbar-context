import React from 'react';

import '../App.css';

import Form from './Form';

const FormWrapper = () => {
    return (
        <Form />
    )
}

export default FormWrapper;